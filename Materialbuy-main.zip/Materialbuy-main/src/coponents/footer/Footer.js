import React from 'react';
/* eslint-disable */
function Footer() {
  return (
    <>
     <footer className="footer">
   
     MaterialBuy © 2022 - Developed by  <span className="d-none d-sm-inline-block"><a target="_blank" rel="noopener" href="https://techqkonnect.com/">Techq Konnect</a></span>.
        </footer>
    </>
  );
}

export default Footer;
