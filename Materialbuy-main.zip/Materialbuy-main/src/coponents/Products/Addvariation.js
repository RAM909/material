import React from 'react';
import Footer from '../footer/Footer';

function Addvariation() {
  return (
    <div>
      <div className="content-page">

<div className="content">
  <div className="container-fluid">
    <div className="page-title-box">
      <div className="row align-items-center">
        <div className="col-sm-6">
          <h4 className="page-title">Add variation</h4>
        </div>
        
      </div>
    </div>

   


    <div className="row">
      <div className="col-xl-12">
        <div className="card m-b-30">
          <div className="card-body">
            <h4 className="mt-0 header-title mb-4">Order List


            </h4>





            <div className="table-responsive">
             
            </div>
            

          </div>
        </div>
      </div>
    </div>


  </div>


</div>
<Footer />

</div>
    </div>
  );
}

export default Addvariation;
